import json

# Hitta datorerna som inte ligger nära samt med threshold kunna bestämma hur nära två enheter kan anses vara samma plats.

def solution_find_stolen_computers(filename="tracking.json", threshold=0.05):
    with open(filename, "r", encoding="utf-8") as file:
        data = json.load(file)
 # Set som lagrar enheter som INTE är stulna
 # dvs de som har en enhet inom threshold av sig själva
    not_stolen = set()
    # gör items till lista så att vi kan loopa index
    items = list(data.items())

    # Jämföra varje enhet mot varje annan enhet
    for i in range(len(items)):
        name1, (lat1, lon1) = items[i]
    
        for j in range(i + 1, len(items)):
            name2, (lat2, lon2) = items[j]

            # Här kontrollererar vi om två enheter är nära varann
            # Om avståndet i lat och lon är under threshold

            if abs(lat1 - lat2) < threshold and abs(lon1 - lon2) < threshold:
                # Om de är nära = inte stulen
                not_stolen.add(name1)
                not_stolen.add(name2)

    # Resten av enheter som INTE finns i not_stolen = misstänkt stulna 
    stolen_computers = [name for name in data.keys() if name not in not_stolen] 

    # returnerar första namnet om listan inte är tom
    if stolen_computers:
        return stolen_computers[0]
    else:
        return None 
    


def test_solution_find_stolen_computers():
    
    # körfunktion
    result = solution_find_stolen_computers("tracking.json")
    
    # Ska vara en sträng
    assert type(result) == str, "solution() should return a string"

    # Strängen ska inte vara tom
    assert len(result) > 0, "solution() should not return an empty string"