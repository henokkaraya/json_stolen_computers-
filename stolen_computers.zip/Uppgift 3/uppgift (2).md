# Uppgift 3

## Bakgrund

Hackarna har avslöjat att de inte bara lyckats komma åt
företagets hemsida, de har dessutom tagit sig in och stulit
en dator med alla kontouppgifter.

Vad de förhoppningsvis inte vet är att IT-säkerhetsavdelningen
gömt spårsändare i alla företagets datorer. Datorerna skickar
regelbundet ut sin position som longitud och latitud, och detta
sparas i en fil som heter `tracking.json`.

## Uppgift

Din uppgift är att skriva en funktion som läser filen
`tracking.json`, och hitta latitud och longitud för den stulna
datorn.

Med lite tur befinner sig den stulna datorn inte i närheten av
någon annan av företagets datorer.

Hitta vilken av datorerna som befinner sig ensam på en plats.

Inlämningen ska bestå både av namnet på den stulna datorn och
programmet som löser uppgiften!

## Tips

Datorernas positioner lagras som en tuple med (latitud, longitud).
Positionerna för datorer på samma plats är nära varandra, men inte
exakt lika.

Jämför alla datorers positioner med varandra. Om två datorer är
på ungefär samma plats så är de inte stulna. Markera dem i t.ex.
en dict.

Den dator som inte är markerad är svaret på uppgiften.

För att jämföra två flyttal med varandra kan man göra så här:

Räkna ut `abs(A - B)` och jämför resultatet med ett litet värde,
tex 0.05. Om resultatet av uträkningen är nära 0 kan talen anses
vara lika. `abs()` är en inbyggd funktion i Python som ger
absolutvärdet för ett tal: `abs(1)` är 1, `abs(-1)` är också 1.

## Länkar

- https://docs.python.org/3/library/json.html

  Modulen i Python för att läsa json från en sträng.

- https://docs.python.org/3/tutorial/floatingpoint.html

  Mer om flyttal i Python.
